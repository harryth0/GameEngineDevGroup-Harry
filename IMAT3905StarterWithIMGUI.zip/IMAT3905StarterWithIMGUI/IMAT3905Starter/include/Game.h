#pragma once
#include "IEngineCore.h"
#include "InputHandler.h"
#include "LevelEditor.h"

class Model;
class Scene;

class Game
{
public:
	Game(IEngineCore* engine);
	virtual ~Game();

	virtual void update(float dt) = 0;
	virtual void render() = 0;

	// added these to render the imgui menus
	virtual void imguiInit() = 0;
	virtual void imguiRender() = 0;
	virtual void imguiShutdown() = 0;
	
	InputHandler* getInputHandler();

protected:
	IEngineCore* m_engineInterfacePtr;
	InputHandler* m_inputHandler;
	Scene* m_scene;

	LevelEditor* m_levelEditor;
};
