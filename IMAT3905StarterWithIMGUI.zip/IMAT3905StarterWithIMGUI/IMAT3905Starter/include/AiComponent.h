#pragma once
#include "Component.h"
#include "TransformComponent.h"
#include "GameObject.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/quaternion.hpp>
#include <glm/gtx/string_cast.hpp>
#include <iostream>

class AiComponent : public Component
{
	void OnUpdate(float dt) override {}
	void OnMessage(const std::string m) override {}

private:

public:

	const TransformComponent* transform;
	glm::vec3 m_position;
	glm::quat orientation;
	
	AiComponent() {}
	AiComponent(glm::vec3 pos) : m_position(pos) {}
	AiComponent(TransformComponent* tc) : transform(tc) {}

	//const glm::vec3& position() const { return m_position; }

	glm::vec3 getPosition()
	{
		//return m_position;
		return transform->m_position;
	}


	void setPosition(const glm::vec3& newPos)
	{
		//m_position = newPos;
		//transform->m_position = newPos;
	}

	void setOrientation(const glm::quat& orient)
	{
		orientation = orient;
	}

	void setTransformComponent(TransformComponent* tc)
	{
		//transform = getComponent
	}
	
	void setNodes(/*array of nodes*/)
	{
		
	}

	void follow(TransformComponent* target) 
	{
		
		//transform->getOrientation() = (glm::toQuat(glm::lookAt(transform->m_position, target->m_position, glm::vec3(0, 1, 0))));
		std::cout << glm::to_string(getPosition()) << std::endl;
		//std::cout << glm::to_string(orientation) << std::endl;
		//std::cout << glm::to_string(m_position) << std::endl;

	}

	void moveTo()
	{

	}
};

/* nodes have position data*/