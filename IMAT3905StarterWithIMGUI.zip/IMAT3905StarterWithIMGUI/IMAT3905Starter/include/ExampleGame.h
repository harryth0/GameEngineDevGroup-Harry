#pragma once
#include "Game.h"
#include <map>

class ModelManager;

class ExampleGame : public Game
{
public:
	ExampleGame(IEngineCore* engine);
	void update(float dt) override;
	void render() override;
	void Initialise();

	virtual void imguiInit();
	virtual void imguiRender();
	virtual void imguiShutdown();

private:

	ModelManager* m_theModelManager;
	bool editor = false;

	//Assign starting scene here -Harry
	std::string m_sceneIndex = "MainMenu";

	/*
	Have changed the level names from an array to a map.
	Map allows data (levels) to be added. Starting maps are set in the example game constructor.
	*/
	std::map<std::string, std::string> m_levelNames;
};
