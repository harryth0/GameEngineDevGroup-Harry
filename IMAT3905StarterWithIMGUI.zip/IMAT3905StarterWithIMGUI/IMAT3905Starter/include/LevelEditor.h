#pragma once

#include "GameObject.h"
#include "Model.h"
#include "ModelManager.h"
#include "Scene.h"

#include "IEngineCore.h"
#include "JSON\json.h"

//imgui
#include <imgui.h>
#include "imgui_impl_glfw_gl3.h"
#include <vector>

class ModelManager;

class LevelEditor
{
public:

	LevelEditor(ModelManager* theModelManager);

	void CreateObject(std::string name);
	void SaveJSON(std::string name, std::map<std::string, std::string> m_levelNames);

	void Render(IEngineCore* engineCore);
	void imguiRender(Scene scene, std::map<std::string, std::string> m_levelNames);

private:

	int incriment = 1;
	vector<std::string>models;
	vector<std::string>originalName;

	glm::vec3 position;

	Json::Value gameObjects;
	Json::Value obj;

	std::string input;
	//std::string name;

	ModelManager* m_theModelManager;

	Model* model;
	std::vector<GameObject*> v_gameObjects;
	GameObject* currentObject;
	string currentObjectName;
	int currentIndex = 0;

	bool hasObject = false;

	float* fpx = { 0 };
	float* fpy = { 0 };
	float* fpz = { 0 };

	float angleY = 0; //yaw
	float angleX = 0; //pitch

	int localState = 0;
	bool bPlayer = false;
	bool bStatic = true;
	bool bNonStatic = false;
	bool bNode = false;
};

